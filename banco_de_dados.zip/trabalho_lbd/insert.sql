INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (1, 0, 0, 0);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (2, 0, 1, 1);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (3, 0, 2, 2);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (4, 0, 3, 3);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (5, 0, 4, 4);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (6, 0, 5, 5);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (7, 0, 6, 6);

INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (8, 1, 1, 2);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (9, 1, 2, 3);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (10, 1, 3, 4);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (11, 1, 4, 5);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (12, 1, 5, 6);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (13, 1, 6, 7);

INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (14, 2, 2, 4);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (15, 2, 3, 5);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (16, 2, 4, 6);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (17, 2, 5, 7);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (18, 2, 6, 8);

INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (19, 3, 3, 6);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (20, 3, 4, 7);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (21, 3, 5, 8);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (22, 3, 6, 9);

INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (23, 4, 4, 8);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (24, 4, 5, 9);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (25, 4, 6, 10);

INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (26, 5, 5, 10);
INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (27, 5, 6, 11);

INSERT INTO Peca (id_peca, ponta_1, ponta_2, valor) VALUES (28, 6, 6, 12);
