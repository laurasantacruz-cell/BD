CREATE OR REPLACE FUNCTION comprar_peca(idPartida INT, idJogador INT)
RETURNS VOID AS $$
DECLARE
    pecaComprada INT;
BEGIN
    SELECT id_peca INTO pecaComprada
    FROM Monte_comprar
    WHERE id_partida = idPartida
    LIMIT 1;

    IF pecaComprada IS NULL THEN
        RAISE NOTICE 'Monte vazio';
        RETURN;
    END IF;

    INSERT INTO Mao_do_jogador(id_partida, id_jogador, id_peca)
    VALUES (idPartida, idJogador, pecaComprada);

    DELETE FROM Monte_comprar
    WHERE id_partida = idPartida
      AND id_peca = pecaComprada;
END;
$$ LANGUAGE plpgsql;
