CREATE OR REPLACE VIEW ranking_jogadores AS
SELECT
    u.id_usuario,
    u.nome,
    COUNT(p.id_partida) FILTER (WHERE p.vencedor = j.id_jogador) AS partidas_vencidas,
    COUNT(p.id_partida) AS partidas_jogadas,
    COALESCE(SUM(p.pontos_vencidos), 0) AS total_pontos_ganhos
FROM Usuario u
LEFT JOIN Jogador j ON j.id_usuario = u.id_usuario
LEFT JOIN Partida p ON p.id_jogo = j.id_jogo
GROUP BY u.id_usuario, u.nome;



CREATE OR REPLACE VIEW partidas_vencedores AS
SELECT
    p.id_partida,
    p.id_jogo,
    p.numero_partida,
    p.modo_fim,
    p.vencedor AS id_jogador_vencedor
FROM Partida p;



CREATE OR REPLACE VIEW historico_jogadas AS
SELECT
    jg.id_jogada,
    jg.id_partida,
    jg.id_jogador,
    u.nome AS nome_jogador,
    jg.id_peca,
    p.ponta_1,
    p.ponta_2,
    p.valor,
    jg.acao,
    jg.lado,
    jg.ordem_jogada,
    jg.data_hora
FROM Jogada jg
LEFT JOIN Jogador j ON j.id_jogador = jg.id_jogador
LEFT JOIN Usuario u ON u.id_usuario = j.id_usuario
LEFT JOIN Peca p ON p.id_peca = jg.id_peca
ORDER BY jg.id_partida, jg.ordem_jogada;



CREATE OR REPLACE VIEW estado_mesa_atual AS
SELECT
    em.id_partida,
    em.id_peca,
    p.ponta_1,
    p.ponta_2,
    p.valor,
    em.ordem
FROM Estado_da_mesa em
JOIN Peca p ON p.id_peca = em.id_peca
ORDER BY em.id_partida, em.ordem;



CREATE OR REPLACE VIEW mao_jogadores AS
SELECT
    m.id_partida,
    j.id_jogador,
    u.nome AS nome_jogador,
    m.id_peca,
    p.ponta_1,
    p.ponta_2,
    p.valor
FROM Mao_do_jogador m
JOIN Jogador j ON j.id_jogador = m.id_jogador
JOIN Usuario u ON u.id_usuario = j.id_usuario
JOIN Peca p ON p.id_peca = m.id_peca
ORDER BY m.id_partida, j.id_jogador;



CREATE OR REPLACE VIEW pecas_distribuidas_view AS
SELECT
    pd.id_partida,
    pd.id_jogador,
    u.nome AS nome_jogador,
    pd.id_peca,
    p.ponta_1,
    p.ponta_2,
    p.valor
FROM Pecas_distribuidas pd
JOIN Jogador j ON j.id_jogador = pd.id_jogador
JOIN Usuario u ON u.id_usuario = j.id_usuario
JOIN Peca p ON p.id_peca = pd.id_peca
ORDER BY pd.id_partida, pd.id_jogador;



CREATE OR REPLACE VIEW partidas_completas AS
SELECT
    p.id_partida,
    p.id_jogo,
    p.numero_partida,
    p.modo_fim,
    p.vencedor,
    u.nome AS nome_vencedor,
    p.pontos_vencidos,
    p.pontos_perdidos,
    p.data_inicio,
    p.data_fim
FROM Partida p
LEFT JOIN Jogador j ON j.id_jogador = p.vencedor
LEFT JOIN Usuario u ON u.id_usuario = j.id_usuario;



CREATE OR REPLACE VIEW jogos_com_jogadores AS
SELECT
    jg.id_jogo,
    jg.modo,
    jg.data_inicio,
    jg.data_fim,
    j.id_jogador,
    u.nome AS nome_jogador,
    j.id_dupla,
    j.posicao
FROM Jogo jg
LEFT JOIN Jogador j ON j.id_jogo = jg.id_jogo
LEFT JOIN Usuario u ON u.id_usuario = j.id_usuario
ORDER BY jg.id_jogo, j.posicao;