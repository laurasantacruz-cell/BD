CREATE TABLE Usuario (
    id_usuario SERIAL PRIMARY KEY,
    nome TEXT NOT NULL,
    senha TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    data_cadastro TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE Jogo (
    id_jogo SERIAL PRIMARY KEY,
    modo TEXT NOT NULL,
    data_inicio TIMESTAMP,
    data_fim TIMESTAMP,
    estado TEXT,
    pontuacao_final INTEGER,
    id_usuario INTEGER NOT NULL REFERENCES Usuario(id_usuario)
);

CREATE TABLE Dupla (
    id_dupla SERIAL PRIMARY KEY,
    id_jogo INTEGER NOT NULL REFERENCES Jogo(id_jogo)
);

CREATE TABLE Jogador (
    id_jogador SERIAL PRIMARY KEY,
    id_usuario INTEGER NOT NULL REFERENCES Usuario(id_usuario),
    id_jogo INTEGER NOT NULL REFERENCES Jogo(id_jogo),
    id_dupla INTEGER REFERENCES Dupla(id_dupla),
    posicao INTEGER NOT NULL
);

CREATE TABLE Partida (
    id_partida SERIAL PRIMARY KEY,
    id_jogo INTEGER NOT NULL REFERENCES Jogo(id_jogo),
    numero_partida INTEGER NOT NULL,
    data_inicio TIMESTAMP,
    data_fim TIMESTAMP,
    vencedor INTEGER,
    modo_fim TEXT,
    pontos_vencidos INTEGER,
    pontos_perdidos INTEGER
);

CREATE TABLE Peca (
    id_peca SERIAL PRIMARY KEY,
    ponta_1 INTEGER NOT NULL,
    ponta_2 INTEGER NOT NULL,
    valor INTEGER NOT NULL
);

CREATE TABLE Pecas_distribuidas (
    id_partida INTEGER NOT NULL REFERENCES Partida(id_partida),
    id_jogador INTEGER NOT NULL REFERENCES Jogador(id_jogador),
    id_peca INTEGER NOT NULL REFERENCES Peca(id_peca),
    PRIMARY KEY (id_partida, id_jogador, id_peca)
);

CREATE TABLE Mao_do_jogador (
    id_partida INTEGER NOT NULL REFERENCES Partida(id_partida),
    id_jogador INTEGER NOT NULL REFERENCES Jogador(id_jogador),
    id_peca INTEGER NOT NULL REFERENCES Peca(id_peca),
    PRIMARY KEY (id_partida, id_jogador, id_peca)
);

CREATE TABLE Monte_comprar (
    id_partida INTEGER NOT NULL REFERENCES Partida(id_partida),
    id_peca INTEGER NOT NULL REFERENCES Peca(id_peca),
    PRIMARY KEY (id_partida, id_peca)
);

CREATE TABLE Jogada (
    id_jogada SERIAL PRIMARY KEY,
    id_jogador INTEGER NOT NULL REFERENCES Jogador(id_jogador),
    id_partida INTEGER NOT NULL REFERENCES Partida(id_partida),
    id_peca INTEGER REFERENCES Peca(id_peca),
    ordem_jogada INTEGER NOT NULL,
    data_hora TIMESTAMP NOT NULL,
    lado TEXT,
    acao TEXT NOT NULL
);

CREATE TABLE Estado_da_mesa (
    id_estado SERIAL PRIMARY KEY,
    id_partida INTEGER NOT NULL REFERENCES Partida(id_partida),
    id_peca INTEGER NOT NULL REFERENCES Peca(id_peca),
    ordem INTEGER NOT NULL
);
