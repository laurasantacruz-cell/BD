CREATE OR REPLACE FUNCTION jogadas_possiveis(idPartida INT, idJogador INT)
RETURNS BOOLEAN AS $$
DECLARE
    esquerda INT;
    direita INT;
    p RECORD;
BEGIN
    SELECT p.ponta_1 INTO esquerda
    FROM Estado_da_mesa e
    JOIN Peca p ON e.id_peca = p.id_peca
    WHERE e.id_partida = idPartida
    ORDER BY e.ordem ASC
    LIMIT 1;

    SELECT p.ponta_2 INTO direita
    FROM Estado_da_mesa e
    JOIN Peca p ON e.id_peca = p.id_peca
    WHERE e.id_partida = idPartida
    ORDER BY e.ordem DESC
    LIMIT 1;

    IF esquerda IS NULL OR direita IS NULL THEN
        FOR p IN
            SELECT pe.ponta_1, pe.ponta_2
            FROM Mao_do_jogador m
            JOIN Peca pe ON m.id_peca = pe.id_peca
            WHERE m.id_partida = idPartida
            AND m.id_jogador = idJogador
        LOOP
            IF p.ponta_1 = 6 AND p.ponta_2 = 6 THEN
                RETURN TRUE;
            END IF;
        END LOOP;
        RETURN FALSE;
    END IF;

    FOR p IN
        SELECT pe.ponta_1, pe.ponta_2
        FROM Mao_do_jogador m
        JOIN Peca pe ON m.id_peca = pe.id_peca
        WHERE m.id_partida = idPartida
        AND m.id_jogador = idJogador
    LOOP
        IF p.ponta_1 = esquerda OR p.ponta_2 = esquerda OR p.ponta_1 = direita OR p.ponta_2 = direita THEN
            RETURN TRUE;
        END IF;
    END LOOP;

    RETURN FALSE;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION validar_jogada(idPartida INT, idJogador INT, idPeca INT, lado TEXT)
RETURNS BOOLEAN AS $$
DECLARE
    esquerda INT;
    direita INT;
    p1 INT;
    p2 INT;
BEGIN
    SELECT ponta_1, ponta_2 INTO p1, p2
    FROM Peca
    WHERE id_peca = idPeca;

    SELECT p.ponta_1 INTO esquerda
    FROM Estado_da_mesa e
    JOIN Peca p ON e.id_peca = p.id_peca
    WHERE e.id_partida = idPartida
    ORDER BY e.ordem ASC
    LIMIT 1;

    SELECT p.ponta_2 INTO direita
    FROM Estado_da_mesa e
    JOIN Peca p ON e.id_peca = p.id_peca
    WHERE e.id_partida = idPartida
    ORDER BY e.ordem DESC
    LIMIT 1;

    IF esquerda IS NULL OR direita IS NULL THEN
        IF p1 = 6 AND p2 = 6 THEN
            RETURN TRUE;
        ELSE
            RETURN FALSE;
        END IF;
    END IF;

    IF lado = 'esquerda' THEN
        IF p1 = esquerda OR p2 = esquerda THEN
            RETURN TRUE;
        ELSE
            RETURN FALSE;
        END IF;
    END IF;

    IF lado = 'direita' THEN
        IF p1 = direita OR p2 = direita THEN
            RETURN TRUE;
        ELSE
            RETURN FALSE;
        END IF;
    END IF;

    RETURN FALSE;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION detectar_jogo_trancado(idPartida INT)
RETURNS BOOLEAN AS $$
DECLARE
    j RECORD;
BEGIN
    FOR j IN
        SELECT id_jogador
        FROM Jogador
        WHERE id_jogo = (
            SELECT id_jogo FROM Partida WHERE id_partida = idPartida
        )
    LOOP
        IF jogadas_possiveis(idPartida, j.id_jogador) THEN
            RETURN FALSE;
        END IF;
    END LOOP;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION calcular_pontos_partida(idPartida INT)
RETURNS VOID AS $$
DECLARE
    j RECORD;
    soma1 INT := 0;
    soma2 INT := 0;
    vencedord INT;
BEGIN
    FOR j IN
        SELECT jg.id_dupla, COALESCE(SUM(p.valor), 0) AS pontos
        FROM Jogador jg
        LEFT JOIN Mao_do_jogador m ON m.id_jogador = jg.id_jogador AND m.id_partida = idPartida
        LEFT JOIN Peca p ON p.id_peca = m.id_peca
        WHERE jg.id_jogo = (SELECT id_jogo FROM Partida WHERE id_partida = idPartida)
        GROUP BY jg.id_dupla
    LOOP
        IF j.id_dupla = 1 THEN
            soma1 := j.pontos;
        ELSE
            soma2 := j.pontos;
        END IF;
    END LOOP;

    IF (SELECT modo_fim FROM Partida WHERE id_partida = idPartida) = 'batida' THEN
        vencedord := (SELECT id_dupla FROM Jogador WHERE id_jogador = (SELECT vencedor FROM Partida WHERE id_partida = idPartida));
        IF vencedord = 1 THEN
            UPDATE Partida SET pontos_vencidos = soma2 WHERE id_partida = idPartida;
        ELSE
            UPDATE Partida SET pontos_vencidos = soma1 WHERE id_partida = idPartida;
        END IF;
        RETURN;
    END IF;

    IF (SELECT modo_fim FROM Partida WHERE id_partida = idPartida) = 'trancado' THEN
        IF soma1 < soma2 THEN
            UPDATE Partida SET vencedor = (SELECT id_jogador FROM Jogador WHERE id_dupla = 1 LIMIT 1),
                               pontos_vencidos = soma2
            WHERE id_partida = idPartida;
        ELSIF soma2 < soma1 THEN
            UPDATE Partida SET vencedor = (SELECT id_jogador FROM Jogador WHERE id_dupla = 2 LIMIT 1),
                               pontos_vencidos = soma1
            WHERE id_partida = idPartida;
        ELSE
            UPDATE Partida SET vencedor = (SELECT id_jogador FROM Jogador WHERE id_dupla = 2 LIMIT 1),
                               pontos_vencidos = soma1
            WHERE id_partida = idPartida;
        END IF;
        RETURN;
    END IF;
END;
$$ LANGUAGE plpgsql;