CREATE OR REPLACE FUNCTION gatilho_validar_jogada()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.acao = 'jogar' THEN
        IF NOT validar_jogada(NEW.id_partida, NEW.id_jogador, NEW.id_peca, NEW.lado) THEN
            RAISE EXCEPTION 'Jogada inválida';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_validar_jogada
BEFORE INSERT ON Jogada
FOR EACH ROW
EXECUTE FUNCTION gatilho_validar_jogada();

CREATE OR REPLACE FUNCTION gatilho_remover_da_mao()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.acao = 'jogar' THEN
        DELETE FROM Mao_do_jogador
        WHERE id_partida = NEW.id_partida
          AND id_jogador = NEW.id_jogador
          AND id_peca = NEW.id_peca;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_remover_mao
AFTER INSERT ON Jogada
FOR EACH ROW
EXECUTE FUNCTION gatilho_remover_da_mao();

CREATE OR REPLACE FUNCTION gatilho_inserir_mesa()
RETURNS TRIGGER AS $$
DECLARE
    prox INT;
BEGIN
    IF NEW.acao = 'jogar' THEN
        SELECT COALESCE(MAX(ordem), 0) + 1 INTO prox
        FROM Estado_da_mesa
        WHERE id_partida = NEW.id_partida;

        INSERT INTO Estado_da_mesa(id_partida, id_peca, ordem)
        VALUES (NEW.id_partida, NEW.id_peca, prox);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_inserir_mesa
AFTER INSERT ON Jogada
FOR EACH ROW
EXECUTE FUNCTION gatilho_inserir_mesa();

CREATE OR REPLACE FUNCTION gatilho_detectar_batida()
RETURNS TRIGGER AS $$
DECLARE
    qtd INT;
BEGIN
    SELECT COUNT(*) INTO qtd
    FROM Mao_do_jogador
    WHERE id_partida = NEW.id_partida
      AND id_jogador = NEW.id_jogador;

    IF qtd = 0 THEN
        UPDATE Partida
        SET vencedor = NEW.id_jogador,
            modo_fim = 'batida'
        WHERE id_partida = NEW.id_partida;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_detectar_batida
AFTER INSERT ON Jogada
FOR EACH ROW
EXECUTE FUNCTION gatilho_detectar_batida();

CREATE OR REPLACE FUNCTION gatilho_trancamento()
RETURNS TRIGGER AS $$
DECLARE
    j RECORD;
    pode BOOLEAN := FALSE;
    jogo INT;
BEGIN
    SELECT id_jogo INTO jogo FROM Partida WHERE id_partida = NEW.id_partida;

    FOR j IN SELECT id_jogador FROM Jogador WHERE id_jogo = jogo LOOP
        IF jogadas_possiveis(NEW.id_partida, j.id_jogador) THEN
            pode := TRUE;
        END IF;
    END LOOP;

    IF NOT pode THEN
        UPDATE Partida SET modo_fim = 'trancado' WHERE id_partida = NEW.id_partida;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_trancamento
AFTER INSERT ON Jogada
FOR EACH ROW
EXECUTE FUNCTION gatilho_trancamento();

CREATE OR REPLACE FUNCTION gatilho_finalizar_pontos()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.modo_fim IN ('batida', 'trancado') THEN
        PERFORM calcular_pontos_partida(NEW.id_partida);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_finalizar_pontos
AFTER UPDATE OF modo_fim ON Partida
FOR EACH ROW
EXECUTE FUNCTION gatilho_finalizar_pontos();