import random

def carregar_pecas(conn):
    cur = conn.cursor()
    cur.execute("SELECT id_peca, ponta_1, ponta_2, valor FROM Peca")
    pecas = cur.fetchall()
    cur.close()
    return pecas

def embaralhar(lista_pecas):
    pecas = lista_pecas.copy()
    random.shuffle(pecas)
    return pecas

def distribuir_pecas(pecas_embaralhadas, qtd_jogadores):
    maos = []
    index = 0
    for _ in range(qtd_jogadores):
        mao = pecas_embaralhadas[index:index + 7]
        index += 7
        maos.append(mao)
    monte = pecas_embaralhadas[index:]
    return maos, monte

def linha_para_dict(cursor, row):
    return {desc[0]: col for desc, col in zip(cursor.description, row)}