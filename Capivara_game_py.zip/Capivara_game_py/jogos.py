from db import get_connection

def criar_jogo(modo, id_usuario):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO Jogo (modo, id_usuario) VALUES (%s, %s) RETURNING id_jogo",
        (modo, id_usuario)
    )
    id_jogo = cur.fetchone()[0]
    conn.commit()
    cur.close()
    conn.close()
    return id_jogo

def criar_dupla(id_jogo):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO Dupla (id_jogo) VALUES (%s) RETURNING id_dupla",
        (id_jogo,)
    )
    id_dupla = cur.fetchone()[0]
    conn.commit()
    cur.close()
    conn.close()
    return id_dupla

def adicionar_jogador(id_usuario, id_jogo, id_dupla, posicao):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO Jogador (id_usuario, id_jogo, id_dupla, posicao) VALUES (%s, %s, %s, %s) RETURNING id_jogador",
        (id_usuario, id_jogo, id_dupla, posicao)
    )
    id_jogador = cur.fetchone()[0]
    conn.commit()
    cur.close()
    conn.close()
    return id_jogador

def iniciar_jogo(id_jogo):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "UPDATE Jogo SET data_inicio = NOW(), estado = 'iniciado' WHERE id_jogo = %s",
        (id_jogo,)
    )
    conn.commit()
    cur.close()
    conn.close()
    return True

def finalizar_jogo(id_jogo, pontuacao_final):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "UPDATE Jogo SET data_fim = NOW(), estado = 'finalizado', pontuacao_final = %s WHERE id_jogo = %s",
        (pontuacao_final, id_jogo)
    )
    conn.commit()
    cur.close()
    conn.close()
    return True