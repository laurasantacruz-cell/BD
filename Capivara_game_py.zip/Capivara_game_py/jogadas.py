from db import get_connection

def obter_ordem(id_partida):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT COALESCE(MAX(ordem_jogada), 0) + 1 FROM Jogada WHERE id_partida = %s",
        (id_partida,)
    )
    ordem = cur.fetchone()[0]
    cur.close()
    conn.close()
    return ordem

def jogar_peca(id_partida, id_jogador, id_peca, lado):
    ordem = obter_ordem(id_partida)
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "DELETE FROM Mao_do_jogador WHERE id_partida = %s AND id_jogador = %s AND id_peca = %s",
        (id_partida, id_jogador, id_peca)
    )
    cur.execute(
        "INSERT INTO Jogada (id_jogador, id_partida, id_peca, ordem_jogada, data_hora, lado, acao) VALUES (%s, %s, %s, %s, NOW(), %s, 'jogar')",
        (id_jogador, id_partida, id_peca, ordem, lado)
    )
    cur.execute(
        "INSERT INTO Estado_da_mesa (id_partida, id_peca, ordem) VALUES (%s, %s, %s)",
        (id_partida, id_peca, ordem)
    )
    conn.commit()
    cur.close()
    conn.close()
    return True

def comprar_peca(id_partida, id_jogador):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT id_peca FROM Monte_comprar WHERE id_partida = %s LIMIT 1",
        (id_partida,)
    )
    linha = cur.fetchone()
    if not linha:
        cur.close()
        conn.close()
        return None
    id_peca = linha[0]
    cur.execute(
        "DELETE FROM Monte_comprar WHERE id_partida = %s AND id_peca = %s",
        (id_partida, id_peca)
    )
    cur.execute(
        "INSERT INTO Mao_do_jogador (id_partida, id_jogador, id_peca) VALUES (%s, %s, %s)",
        (id_partida, id_jogador, id_peca)
    )
    ordem = obter_ordem(id_partida)
    cur.execute(
        "INSERT INTO Jogada (id_jogador, id_partida, id_peca, ordem_jogada, data_hora, acao) VALUES (%s, %s, %s, %s, NOW(), 'comprar')",
        (id_jogador, id_partida, id_peca, ordem)
    )
    conn.commit()
    cur.close()
    conn.close()
    return id_peca

def passar_vez(id_partida, id_jogador):
    ordem = obter_ordem(id_partida)
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO Jogada (id_jogador, id_partida, ordem_jogada, data_hora, acao) VALUES (%s, %s, %s, NOW(), 'passar')",
        (id_jogador, id_partida, ordem)
    )
    conn.commit()
    cur.close()
    conn.close()
    return True