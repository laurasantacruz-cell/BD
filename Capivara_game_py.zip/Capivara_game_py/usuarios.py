from db import get_connection

def criar_usuario(nome, email, senha):
    conn = get_connection()
    cur = conn.cursor()

    try:
        cur.execute("""
            INSERT INTO Usuario (nome, email, senha)
            VALUES (%s, %s, %s)
            RETURNING id_usuario;
        """, (nome, email, senha))

        id_usuario = cur.fetchone()[0]
        conn.commit()
        return id_usuario

    except Exception as e:
        conn.rollback()
        print("Erro ao criar usuário:", e)
        return None

    finally:
        cur.close()
        conn.close()