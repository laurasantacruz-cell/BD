from usuarios import criar_usuario

id_novo = criar_usuario("Chico", "chico@example.com", "senha123")

print("ID do novo usuário:", id_novo)