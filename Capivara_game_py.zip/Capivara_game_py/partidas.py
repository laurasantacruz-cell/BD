from db import get_connection
from utils import carregar_pecas, embaralhar, distribuir_pecas

def criar_partida(id_jogo, numero_partida):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO Partida (id_jogo, numero_partida, data_inicio) VALUES (%s, %s, NOW()) RETURNING id_partida",
        (id_jogo, numero_partida)
    )
    id_partida = cur.fetchone()[0]
    conn.commit()
    cur.close()
    conn.close()
    return id_partida

def carregar_jogadores(id_jogo):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT id_jogador FROM Jogador WHERE id_jogo = %s ORDER BY posicao",
        (id_jogo,)
    )
    lista = [linha[0] for linha in cur.fetchall()]
    cur.close()
    conn.close()
    return lista

def registrar_mao(id_partida, id_jogador, mao):
    conn = get_connection()
    cur = conn.cursor()
    for p in mao:
        cur.execute(
            "INSERT INTO Mao_do_jogador (id_partida, id_jogador, id_peca) VALUES (%s, %s, %s)",
            (id_partida, id_jogador, p[0])
        )
    conn.commit()
    cur.close()
    conn.close()

def registrar_monte(id_partida, monte):
    conn = get_connection()
    cur = conn.cursor()
    for p in monte:
        cur.execute(
            "INSERT INTO Monte_comprar (id_partida, id_peca) VALUES (%s, %s)",
            (id_partida, p[0])
        )
    conn.commit()
    cur.close()
    conn.close()

def iniciar_partida(id_jogo, numero_partida):
    id_partida = criar_partida(id_jogo, numero_partida)
    jogadores = carregar_jogadores(id_jogo)
    conn = get_connection()
    pecas = carregar_pecas(conn)
    conn.close()
    embaralhadas = embaralhar(pecas)
    maos, monte = distribuir_pecas(embaralhadas, len(jogadores))
    for idx, id_j in enumerate(jogadores):
        registrar_mao(id_partida, id_j, maos[idx])
    registrar_monte(id_partida, monte)
    return id_partida