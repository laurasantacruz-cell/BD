import pg8000

def get_connection():
    return pg8000.connect(
        host="localhost",
        database="capivara_game",
        user="postgres",
        password="Betatester3.0",
        port=5432
    )

if __name__ == "__main__":
    try:
        conn = get_connection()
        print("Conectado com sucesso!")
        conn.close()
    except Exception as e:
        print("Erro ao conectar:", e)